#HTML/CSS/JQuery Starter code

Use this starter code to build a website using html, css, and jQuery.

Put any pictures or other assets (pdf's, videos, downloadable files, etc) in the assets folder.
